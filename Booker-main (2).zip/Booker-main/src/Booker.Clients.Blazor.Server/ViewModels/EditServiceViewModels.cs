﻿namespace Booker.Clients.Blazor.Server.ViewModels;

public class EditServiceViewModels
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Calendar is required")]
    public int? CalendarId { get; set; }

    [Required(ErrorMessage = "Name is required")]
    public string? Name { get; set; }

    [Required(ErrorMessage = "Duration is required")]
    [RegularExpression(
        @"^\d{1,3}:[0-5]\d$",
        ErrorMessage = "The format of the Duration is invalid. The correct format: hh:mm"
    )]
    public string? Duration { get; set; }

    [Required(ErrorMessage = "Price is required")]
    public decimal? Price { get; set; }

    public static EditServiceViewModels FromRequest(ServiceDto service)
    {
        return new EditServiceViewModels
        {
            Id = service.Id,
            CalendarId = service.CalendarId,
            Name = service.Name,
            Duration = service.Duration.ToString(@"hh\:mm"),
            Price = service.Price,
        };
    }

    public EditServiceRequest ToRequest()
    {
        return new EditServiceRequest
        {
            Id = Id,
            CalendarId = CalendarId,
            Name = Name,
            Duration = Duration,
            Price = Price,
        };
    }
}
