﻿namespace Booker.Clients.Blazor.Server.Components.Pages.Services;

public partial class Services
{
    private List<ServiceDto> services;
    private string currency;

    protected override async Task OnInitializedAsync()
    {
        // Simulate asynchronous loading to demonstrate streaming rendering
        await Task.Delay(500);

        try
        {
            services = await ServiceApiCaller.GetServices();
            currency = await InfoApiCaller.GetCurrency();
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"An error occurred in {nameof(Services)} during {nameof(OnInitializedAsync)}");
            await JSRuntime.ErrorToast("An error occured during the loading of the page");
        }
    }

    private async Task OnDelete(int id)
    {
        try
        {
            await ServiceApiCaller.DeleteServices(id);

            services = await ServiceApiCaller.GetServices();

            await JSRuntime.SuccessToast("Service deleted");
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"An error occurred in {nameof(Services)} during {nameof(OnDelete)}");
            await JSRuntime.ErrorToast("An error occured during the delete of the service");
        }
    }
}
