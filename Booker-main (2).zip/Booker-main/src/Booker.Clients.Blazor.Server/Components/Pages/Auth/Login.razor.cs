namespace Booker.Clients.Blazor.Server.Components.Pages.Auth;

public partial class Login
{
    [Inject]
    private TokenAuthStateProvider AuthStateProvider { get; set; } = default!;

    private LoginRequest loginModel = new();
    private string? errorMessage;
    private bool isLoading;

    private async Task HandleLogin()
    {
        this.isLoading = true;
        this.errorMessage = null;

        try
        {
            var response = await AuthApiCaller.LoginAsync(this.loginModel);

            if (string.IsNullOrWhiteSpace(response.AccessToken))
            {
                this.errorMessage = "Invalid email or password.";
                return;
            }

            await this.AuthStateProvider.NotifyUserAuthenticationAsync(response.AccessToken, response.RefreshToken);
            NavigationManager.NavigateTo("/");
        }
        catch (ApiCallerException)
        {
            this.errorMessage = "Invalid email or password.";
        }
        catch (Exception)
        {
            this.errorMessage = "An unexpected error occurred. Please try again.";
        }
        finally
        {
            this.isLoading = false;
        }
    }
}
