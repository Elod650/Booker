namespace Booker.Clients.Blazor.Server.Services;

public class SessionStorageService(IJSRuntime jsRuntime)
{
    public async Task<string?> GetItemAsync(string key)
    {
        return await jsRuntime.InvokeAsync<string?>("sessionStorage.getItem", key);
    }

    public async Task SetItemAsync(string key, string value)
    {
        await jsRuntime.InvokeVoidAsync("sessionStorage.setItem", key, value);
    }

    public async Task RemoveItemAsync(string key)
    {
        await jsRuntime.InvokeVoidAsync("sessionStorage.removeItem", key);
    }
}
