namespace Booker.Clients.Blazor.Server.Services;

public class TokenAuthStateProvider(SessionStorageService sessionStorage) : AuthenticationStateProvider
{
    private const string ACCESS_TOKEN_KEY = "accessToken";
    private const string REFRESH_TOKEN_KEY = "refreshToken";

    private readonly ClaimsPrincipal _anonymous = new(new ClaimsIdentity());

    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        try
        {
            string? token = await sessionStorage.GetItemAsync(ACCESS_TOKEN_KEY);

            if (string.IsNullOrWhiteSpace(token))
            {
                return new AuthenticationState(this._anonymous);
            }

            var claims = ParseClaimsFromJwt(token);

            if (claims is null)
            {
                return new AuthenticationState(this._anonymous);
            }

            var expClaim = claims.FirstOrDefault(c => c.Type == "exp");

            if (expClaim is not null)
            {
                long expSeconds = long.Parse(expClaim.Value);
                var expDate = DateTimeOffset.FromUnixTimeSeconds(expSeconds).UtcDateTime;

                if (expDate < DateTime.UtcNow)
                {
                    return new AuthenticationState(this._anonymous);
                }
            }

            var identity = new ClaimsIdentity(claims, "jwt");
            var user = new ClaimsPrincipal(identity);

            return new AuthenticationState(user);
        }
        catch
        {
            return new AuthenticationState(this._anonymous);
        }
    }

    public async Task NotifyUserAuthenticationAsync(string accessToken, string refreshToken)
    {
        await sessionStorage.SetItemAsync(ACCESS_TOKEN_KEY, accessToken);
        await sessionStorage.SetItemAsync(REFRESH_TOKEN_KEY, refreshToken);

        var claims = ParseClaimsFromJwt(accessToken);
        var identity = new ClaimsIdentity(claims, "jwt");
        var user = new ClaimsPrincipal(identity);

        this.NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(user)));
    }

    public async Task NotifyUserLogoutAsync()
    {
        await sessionStorage.RemoveItemAsync(ACCESS_TOKEN_KEY);
        await sessionStorage.RemoveItemAsync(REFRESH_TOKEN_KEY);

        this.NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(this._anonymous)));
    }

    public async Task<string?> GetAccessTokenAsync()
    {
        return await sessionStorage.GetItemAsync(ACCESS_TOKEN_KEY);
    }

    public async Task<string?> GetRefreshTokenAsync()
    {
        return await sessionStorage.GetItemAsync(REFRESH_TOKEN_KEY);
    }

    private static IEnumerable<Claim>? ParseClaimsFromJwt(string jwt)
    {
        string[] parts = jwt.Split('.');

        if (parts.Length != 3)
        {
            return null;
        }

        string payload = parts[1];

        // Pad base64 string if needed
        switch (payload.Length % 4)
        {
            case 2:
                payload += "==";
                break;
            case 3:
                payload += "=";
                break;
        }

        byte[] jsonBytes = Convert.FromBase64String(payload);
        string json = Encoding.UTF8.GetString(jsonBytes);

        var keyValuePairs = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json);

        if (keyValuePairs is null)
        {
            return null;
        }

        List<Claim> claims = [];

        foreach (var kvp in keyValuePairs)
        {
            if (kvp.Value.ValueKind == JsonValueKind.Array)
            {
                foreach (var element in kvp.Value.EnumerateArray())
                {
                    claims.Add(new Claim(kvp.Key, element.GetString() ?? string.Empty));
                }
            }
            else
            {
                claims.Add(new Claim(kvp.Key, kvp.Value.ToString()));
            }
        }

        return claims;
    }
}
